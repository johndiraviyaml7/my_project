/**
 * StudyDetail — Shows series list and DICOM images for a study.
 * 
 * Data strategy:
 *   1. Study metadata from Spring Boot API (PostgreSQL)
 *   2. Series list from BOTH: DB + Orthanc QIDO-RS (merged, Orthanc wins for UIDs)
 *   3. Thumbnails via Orthanc WADO-RS /rendered endpoint
 *   4. OHIF Viewer opened inline as full-screen iframe
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../api/apiService';
import {
  qidoSeries, qidoInstances, wadoRenderedUrl,
  buildOhifUrl, checkOrthancStatus, TAGS, dicomVal,
} from '../api/orthancService';
import OHIFViewer from '../components/OHIFViewer';
import SeriesThumbnail from '../components/SeriesThumbnail';
import styles from './StudyDetail.module.css';

const MODALITY_COLOR = {
  CT:  '#1d4ed8', PT: '#7c3aed', MR: '#059669',
  US:  '#d97706', NM: '#6366f1', SEG: '#dc2626',
};

export default function StudyDetail() {
  const { studyId } = useParams();
  const navigate    = useNavigate();

  const [study,         setStudy]         = useState(null);
  const [dbSeries,      setDbSeries]      = useState([]);
  const [orthancSeries, setOrthancSeries] = useState([]);
  const [selectedSeries,setSelectedSeries]= useState(null);
  const [instances,     setInstances]     = useState([]);
  const [selectedInst,  setSelectedInst]  = useState(null);
  const [activeTab,     setActiveTab]     = useState('series');
  const [showViewer,    setShowViewer]    = useState(false);
  const [orthancOnline, setOrthancOnline] = useState(false);
  const [loading,       setLoading]       = useState(true);
  const [instLoading,   setInstLoading]   = useState(false);

  // ── Effective study UID for Orthanc (de-identified UID if available) ─────
  const orthancStudyUID = study?.orthancStudyUid || study?.deidStudyInstanceUid || study?.studyInstanceUid;

  // ── Merged series list ────────────────────────────────────────────────────
  // Orthanc series take priority; DB series fill gaps (or vice versa if Orthanc offline)
  const mergedSeries = orthancSeries.length > 0
    ? orthancSeries.map(os => {
        const uid = dicomVal(os, TAGS.SeriesInstanceUID);
        const dbMatch = dbSeries.find(d =>
          d.seriesInstanceUid === uid || d.deidSeriesInstanceUid === uid
        );
        return { _source: 'orthanc', _raw: os, _db: dbMatch,
          uid,
          seriesNumber:      dicomVal(os, TAGS.SeriesNumber),
          seriesDescription: dicomVal(os, TAGS.SeriesDescription),
          modality:          dicomVal(os, TAGS.Modality),
          bodyPart:          dicomVal(os, TAGS.BodyPartExamined),
          instanceCount:     dicomVal(os, TAGS.NumberOfSeriesRelatedInstances),
          orthancSeriesId:   dbMatch?.orthancSeriesId,
        };
      })
    : dbSeries.map(s => ({
        _source: 'db', _db: s,
        uid: s.deidSeriesInstanceUid || s.seriesInstanceUid,
        seriesNumber:      s.seriesNumber,
        seriesDescription: s.seriesDescription,
        modality:          s.modality,
        bodyPart:          s.bodyPartExamined,
        instanceCount:     s.imageCount,
        orthancSeriesId:   s.orthancSeriesId,
      }));

  // ── Load study + series ───────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    // Always load from DB
    Promise.all([api.getStudy(studyId), api.getSeries(studyId)])
      .then(([st, sr]) => {
        if (cancelled) return;
        setStudy(st);
        setDbSeries(sr);
      })
      .catch(console.error)
      .finally(() => { if (!cancelled) setLoading(false); });

    // Also try Orthanc directly
    checkOrthancStatus().then(status => {
      if (cancelled || !status?.available) return;
      setOrthancOnline(true);
      // We need the study UID — load study first
      api.getStudy(studyId).then(st => {
        if (cancelled) return;
        const uid = st?.orthancStudyUid || st?.deidStudyInstanceUid || st?.studyInstanceUid;
        if (!uid) return;
        qidoSeries(uid)
          .then(series => { if (!cancelled) setOrthancSeries(series || []); })
          .catch(console.error);
      });
    });

    return () => { cancelled = true; };
  }, [studyId]);

  // ── Load instances when a series is selected ──────────────────────────────
  const handleSelectSeries = useCallback(async (series) => {
    setSelectedSeries(series);
    setSelectedInst(null);
    setInstances([]);
    setActiveTab('instances');
    setInstLoading(true);

    try {
      if (orthancOnline && orthancStudyUID && series.uid) {
        const insts = await qidoInstances(orthancStudyUID, series.uid);
        setInstances(insts || []);
        if (insts?.length > 0) {
          const mid = insts[Math.floor(insts.length / 2)];
          setSelectedInst(mid);
        }
      } else if (series._db) {
        const insts = await api.getInstances(series._db.id);
        setInstances(insts || []);
      }
    } catch (e) {
      console.error('Failed to load instances:', e);
    } finally {
      setInstLoading(false);
    }
  }, [orthancOnline, orthancStudyUID]);

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '60px', color: '#6366f1' }}>
      Loading study…
    </div>
  );
  if (!study) return <div style={{ padding: '40px', color: '#dc2626' }}>Study not found</div>;

  const canOpenViewer = orthancOnline && !!orthancStudyUID;
  const studyDate     = study.studyDate || '—';

  return (
    <div className={styles.page}>
      {/* OHIF full-screen overlay */}
      {showViewer && (
        <OHIFViewer
          studyInstanceUid={orthancStudyUID}
          onClose={() => setShowViewer(false)}
        />
      )}

      {/* Breadcrumb */}
      <div className={styles.breadcrumb}>
        <button onClick={() => navigate('/dicom')} className={styles.breadLink}>Devices</button>
        <span className={styles.sep}>›</span>
        <button onClick={() => navigate(`/dicom/subject/${study.subjectId}`)} className={styles.breadLink}>
          {study.subjectLabel}
        </button>
        <span className={styles.sep}>›</span>
        <span className={styles.breadCurrent}>Study · {studyDate}</span>
      </div>

      {/* Study header */}
      <div className={styles.studyHeader}>
        <div className={styles.studyMeta}>
          <h1 className={styles.studyTitle}>{study.studyDescription || 'Study'}</h1>
          <div className={styles.studyTags}>
            <Tag icon="📅" label={studyDate} />
            <Tag icon="🗂" label={`${mergedSeries.length} series`} />
            <Tag icon="🖼" label={`${study.totalInstances || 0} instances`} />
            {study.accessionNumber && <Tag icon="🔢" label={`ACC: ${study.accessionNumber}`} />}
          </div>
          <div className={styles.uidRow}>
            <span className={styles.uidLabel}>Study UID:</span>
            <code className={styles.uid}>{study.studyInstanceUid}</code>
          </div>
          {study.deidStudyInstanceUid && (
            <div className={styles.uidRow}>
              <span className={styles.uidLabel}>De-id UID:</span>
              <code className={styles.uid} style={{ color: '#16a34a' }}>{study.deidStudyInstanceUid}</code>
            </div>
          )}
        </div>

        {/* Open OHIF button */}
        <div className={styles.viewerCol}>
          {canOpenViewer ? (
            <button className={styles.ohifBtn} onClick={() => setShowViewer(true)}>
              <span className={styles.ohifBtnIcon}>🔬</span>
              <span>Open OHIF Viewer</span>
            </button>
          ) : (
            <div className={styles.ohifOffline}>
              <span>🔬</span>
              <span>{orthancOnline ? 'Study loading…' : 'Orthanc offline'}</span>
            </div>
          )}
          <div className={styles.orthancStatus}>
            <span className={orthancOnline ? styles.dotGreen : styles.dotRed} />
            <span>{orthancOnline ? 'Orthanc connected' : 'Orthanc not reachable'}</span>
          </div>
          {!orthancOnline && (
            <div className={styles.orthancHint}>
              Start Orthanc: <code>docker compose up -d</code>
            </div>
          )}
        </div>
      </div>

      {/* Main: series filmstrip + detail panel */}
      <div className={styles.mainLayout}>

        {/* Left: series cards */}
        <div className={styles.seriesPanel}>
          <div className={styles.panelTitle}>
            Series ({mergedSeries.length})
            {orthancOnline && <span className={styles.liveBadge}>● Live</span>}
          </div>

          {mergedSeries.length === 0 ? (
            <div className={styles.emptyPanel}>
              {orthancOnline
                ? 'No series in Orthanc for this study'
                : 'No series loaded — run Python parser or connect Orthanc'}
            </div>
          ) : (
            <div className={styles.seriesScroll}>
              {mergedSeries.map((s, i) => {
                const isSelected = selectedSeries?.uid === s.uid;
                const mc = MODALITY_COLOR[s.modality] || '#475569';
                return (
                  <div key={s.uid || i}
                    className={`${styles.seriesCard} ${isSelected ? styles.seriesActive : ''}`}
                    onClick={() => handleSelectSeries(s)}>
                    {/* Thumbnail from Orthanc WADO-RS */}
                    <div className={styles.thumbWrap}>
                      {orthancOnline && orthancStudyUID && s.uid ? (
                        <SeriesThumbnail
                          studyUID={orthancStudyUID}
                          seriesUID={s.uid}
                          width={80} height={80}
                        />
                      ) : (
                        <div className={styles.thumbEmpty}>🩻</div>
                      )}
                    </div>
                    <div className={styles.seriesInfo}>
                      <div className={styles.seriesDesc}>
                        {s.seriesDescription || `Series ${s.seriesNumber || i + 1}`}
                      </div>
                      <div className={styles.seriesTags}>
                        <span className={styles.modalityPill} style={{ background: mc + '22', color: mc }}>
                          {s.modality}
                        </span>
                        <span className={styles.instanceCount}>
                          {s.instanceCount || '?'} images
                        </span>
                      </div>
                      {s.bodyPart && <div className={styles.bodyPart}>{s.bodyPart}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: viewer/metadata panel */}
        <div className={styles.detailPanel}>
          {/* Tab bar */}
          <div className={styles.tabBar}>
            {[
              { id: 'series',    label: 'Series Info' },
              { id: 'instances', label: `Instances${instances.length ? ` (${instances.length})` : ''}` },
              { id: 'viewer',    label: '🔬 Viewer' },
            ].map(tab => (
              <button key={tab.id}
                className={`${styles.tab} ${activeTab === tab.id ? styles.tabActive : ''}`}
                onClick={() => {
                  setActiveTab(tab.id);
                  if (tab.id === 'viewer') setShowViewer(true);
                }}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Series info tab */}
          {activeTab === 'series' && (
            <div className={styles.seriesDetail}>
              {!selectedSeries ? (
                <div className={styles.selectHint}>
                  ← Select a series from the left to view details
                </div>
              ) : (
                <div className={styles.metaGrid}>
                  <MetaRow label="Series UID"         value={selectedSeries.uid} mono />
                  <MetaRow label="Modality"           value={selectedSeries.modality} />
                  <MetaRow label="Series Number"      value={selectedSeries.seriesNumber} />
                  <MetaRow label="Description"        value={selectedSeries.seriesDescription} />
                  <MetaRow label="Body Part"          value={selectedSeries.bodyPart} />
                  <MetaRow label="Image Count"        value={selectedSeries.instanceCount} />
                  {selectedSeries._db && <>
                    <MetaRow label="Protocol"          value={selectedSeries._db.protocolName} />
                    <MetaRow label="Manufacturer"      value={selectedSeries._db.manufacturer} />
                    <MetaRow label="Model"             value={selectedSeries._db.manufacturerModel} />
                    <MetaRow label="Slice Thickness"   value={selectedSeries._db.sliceThickness ? `${selectedSeries._db.sliceThickness} mm` : null} />
                    <MetaRow label="Patient Position"  value={selectedSeries._db.patientPosition} />
                    <MetaRow label="De-id Series UID"  value={selectedSeries._db.deidSeriesInstanceUid} mono green />
                  </>}
                </div>
              )}
            </div>
          )}

          {/* Instances + image viewer tab */}
          {activeTab === 'instances' && (
            <div className={styles.instancesLayout}>
              {/* Instance filmstrip */}
              <div className={styles.filmstrip}>
                {instLoading ? (
                  <div className={styles.filmLoading}>Loading instances…</div>
                ) : instances.length === 0 ? (
                  <div className={styles.filmEmpty}>
                    {selectedSeries ? 'No instances found' : 'Select a series first'}
                  </div>
                ) : (
                  instances.map((inst, i) => {
                    const instUID = dicomVal(inst, TAGS.SOPInstanceUID)
                                 || inst?.sopInstanceUid;
                    const instNum = dicomVal(inst, TAGS.SOPInstanceUID)
                                 ? i + 1 : inst?.instanceNumber;
                    const isSelected = selectedInst === inst;

                    return (
                      <div key={instUID || i}
                        className={`${styles.filmFrame} ${isSelected ? styles.filmActive : ''}`}
                        onClick={() => setSelectedInst(inst)}>
                        <div className={styles.filmThumb}>
                          {orthancOnline && orthancStudyUID && selectedSeries?.uid && instUID ? (
                            <img
                              src={wadoRenderedUrl(orthancStudyUID, selectedSeries.uid, instUID, 90, 90)}
                              alt={`Instance ${instNum}`}
                              style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                              onError={e => { e.target.style.display = 'none'; }}
                            />
                          ) : (
                            <span style={{ fontSize: 18, opacity: 0.5 }}>🩻</span>
                          )}
                        </div>
                        <div className={styles.filmNum}>#{instNum}</div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Main image display */}
              <div className={styles.imageDisplay}>
                {selectedInst ? (() => {
                  const instUID = dicomVal(selectedInst, TAGS.SOPInstanceUID)
                               || selectedInst?.sopInstanceUid;
                  if (orthancOnline && orthancStudyUID && selectedSeries?.uid && instUID) {
                    return (
                      <img
                        key={instUID}
                        src={wadoRenderedUrl(orthancStudyUID, selectedSeries.uid, instUID, 600, 600)}
                        alt="DICOM instance"
                        className={styles.mainImage}
                        onError={e => { e.target.style.display = 'none'; }}
                      />
                    );
                  }
                  return <div className={styles.noImageHint}>🩻<br />Image not available</div>;
                })() : (
                  <div className={styles.noImageHint}>
                    {selectedSeries
                      ? '← Select an instance from the filmstrip'
                      : '← Select a series, then an instance'}
                  </div>
                )}

                {/* Image overlay info */}
                {selectedInst && (
                  <div className={styles.imageOverlay}>
                    {selectedSeries?.modality && <span>{selectedSeries.modality}</span>}
                    {(() => {
                      const loc = dicomVal(selectedInst, '00201041')
                               || selectedInst?.sliceLocation;
                      return loc ? <span>Loc: {Number(loc).toFixed(1)} mm</span> : null;
                    })()}
                    <button className={styles.ohifOverlayBtn} onClick={() => setShowViewer(true)}>
                      🔬 Open OHIF
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Tag({ icon, label }) {
  return <span className={styles.tag}>{icon} {label}</span>;
}

function MetaRow({ label, value, mono, green }) {
  if (!value && value !== 0) return null;
  return (
    <div className={styles.mr}>
      <div className={styles.mrLabel}>{label}</div>
      <div className={styles.mrValue} style={{
        fontFamily: mono ? 'monospace' : 'inherit',
        fontSize: mono ? '11px' : '13px',
        color: green ? '#16a34a' : undefined,
        wordBreak: mono ? 'break-all' : undefined,
      }}>{String(value)}</div>
    </div>
  );
}
