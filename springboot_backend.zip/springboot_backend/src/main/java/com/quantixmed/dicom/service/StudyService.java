package com.quantixmed.dicom.service;

import com.quantixmed.dicom.dto.DicomDtos.StudyDto;
import com.quantixmed.dicom.model.Study;
import com.quantixmed.dicom.repository.StudyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class StudyService {

    private final StudyRepository studyRepo;

    public List<StudyDto> listBySubject(UUID subjectId) {
        return studyRepo.findBySubjectIdSorted(subjectId)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    public StudyDto getStudy(UUID id) {
        Study s = studyRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Study not found: " + id));
        return toDto(s);
    }

    private StudyDto toDto(Study s) {
        String subjLabel = s.getSubject() != null ? s.getSubject().getSubjectId() : null;
        return StudyDto.builder()
                .id(s.getId())
                .subjectId(s.getSubject() != null ? s.getSubject().getId() : null)
                .subjectLabel(subjLabel)
                .studyInstanceUid(s.getStudyInstanceUid())
                .studyDate(s.getStudyDate())
                .studyTime(s.getStudyTime())
                .studyDescription(s.getStudyDescription())
                .studyId(s.getStudyId())
                .accessionNumber(s.getAccessionNumber())
                .totalSeries(s.getTotalSeries())
                .totalInstances(s.getTotalInstances())
                                .deidStudyInstanceUid(s.getDeidStudyInstanceUid())
                .deidStudyDate(s.getDeidStudyDate())
                .createdAt(s.getCreatedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
